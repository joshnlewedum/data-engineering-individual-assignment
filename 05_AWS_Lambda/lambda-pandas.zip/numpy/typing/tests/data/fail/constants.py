import numpy as np

np.Inf = np.Inf  # E: Cannot assign to final
np.ALLOW_THREADS = np.ALLOW_THREADS  # E: Cannot assign to final
np.little_endian = np.little_endian  # E: Cannot assign to final
np.UFUNC_PYVALS_NAME = np.UFUNC_PYVALS_NAME  # E: Cannot assign to final
